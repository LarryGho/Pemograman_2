/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.p4_farrel;

/**
 *
 * @author xones
 */
public class P4_Farrel {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
